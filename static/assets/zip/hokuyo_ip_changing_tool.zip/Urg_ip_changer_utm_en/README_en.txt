﻿About the URG IP address changing tool

This is a tool for changing the IP address settings of URG sensor. 
For more details, please refer to manual.chm.

- Licence
  - The licence of Urg_ip_changer belongs to MIT
  - We use Qt LGPL. Please contact us if you need the object code.

File list

- README_En.txt       ... This file
- MANUAL.CHM          ... Update manual
- COPYING_MIT.txt     ... MIT Licence
- COPYING_LGPL.txt    ... LPGL Licence
- Urg_ip_changer.exe  ... Setting tool

If you have any questions, please send us an Email.

mail: support@hokuyo-aut.co.jp
